/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pilhas.e.filas.pucpr;

/**
 *
 * @author wilsonmielke
 */
public class Fila {
    private int primeiro;
    private int ultimo;
    private int dados[];
    public static Fila inicializa(int n){
        Fila f = new Fila();
        f.dados =new int[n];
        f.primeiro = 0;
        f.ultimo = 0;
        return f;
    }
    public boolean cheia(){
        return (this.primeiro-this.ultimo)==this.dados.length;
    }
    public boolean vazia(){
        return this.primeiro==this.ultimo;
    }
    public void insere(int E){
        this.dados[this.primeiro] = E;
        this.primeiro++;
    }
    public void remove(){
        this.dados[this.ultimo] = 0;
        this.ultimo++;
    }
    public void imprime(){
        System.out.print('[');
        for(int dado: this.dados){
            System.out.print(dado+" ");
        }
        System.out.print(']');
    }
    
}
